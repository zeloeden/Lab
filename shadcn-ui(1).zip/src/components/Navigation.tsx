import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/contexts/I18nContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  LayoutDashboard, 
  TestTube, 
  Microscope, 
  Building2, 
  ShoppingCart, 
  CheckSquare, 
  BarChart3, 
  Settings,
  Beaker
} from 'lucide-react';

interface NavItem {
  key: string;
  path: string;
  icon: React.ReactNode;
  label: string;
  labelAR: string;
  resource: string;
  badge?: string;
}

const navItems: NavItem[] = [
  {
    key: 'dashboard',
    path: '/dashboard',
    icon: <LayoutDashboard className="h-5 w-5" />,
    label: 'Dashboard',
    labelAR: 'لوحة التحكم',
    resource: 'analytics'
  },
  {
    key: 'samples',
    path: '/samples',
    icon: <TestTube className="h-5 w-5" />,
    label: 'Samples',
    labelAR: 'العينات',
    resource: 'samples'
  },
  {
    key: 'tests',
    path: '/tests',
    icon: <Microscope className="h-5 w-5" />,
    label: 'Tests',
    labelAR: 'الاختبارات',
    resource: 'tests'
  },
  {
    key: 'suppliers',
    path: '/suppliers',
    icon: <Building2 className="h-5 w-5" />,
    label: 'Suppliers',
    labelAR: 'الموردين',
    resource: 'suppliers'
  },
  {
    key: 'purchasing',
    path: '/purchasing',
    icon: <ShoppingCart className="h-5 w-5" />,
    label: 'Purchasing',
    labelAR: 'المشتريات',
    resource: 'purchasing'
  },
  {
    key: 'tasks',
    path: '/tasks',
    icon: <CheckSquare className="h-5 w-5" />,
    label: 'Tasks',
    labelAR: 'المهام',
    resource: 'tasks'
  },
  {
    key: 'analytics',
    path: '/analytics',
    icon: <BarChart3 className="h-5 w-5" />,
    label: 'Analytics',
    labelAR: 'التحليلات',
    resource: 'analytics'
  },
  {
    key: 'settings',
    path: '/settings',
    icon: <Settings className="h-5 w-5" />,
    label: 'Settings',
    labelAR: 'الإعدادات',
    resource: 'settings'
  }
];

export const Navigation: React.FC = () => {
  const { hasPermission } = useAuth();
  const { t, language } = useI18n();
  const navigate = useNavigate();
  const location = useLocation();

  // Get current active item based on current path
  const getActiveItem = () => {
    const currentPath = location.pathname;
    if (currentPath === '/' || currentPath === '/dashboard') return 'dashboard';
    
    const activeItem = navItems.find(item => item.path === currentPath);
    return activeItem?.key || 'dashboard';
  };

  const activeItem = getActiveItem();

  const visibleItems = navItems.filter(item => 
    hasPermission(item.resource, 'read')
  );

  const handleNavigation = (path: string) => {
    navigate(path);
  };

  return (
    <nav className="w-64 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-lg flex items-center justify-center">
            <Beaker className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">
              NBS LIMS
            </h1>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {t('nav.subtitle', 'Laboratory Management')}
            </p>
          </div>
        </div>
      </div>

      {/* Navigation Items */}
      <div className="flex-1 px-4 py-6 space-y-2">
        {visibleItems.map((item) => (
          <Button
            key={item.key}
            variant={activeItem === item.key ? "default" : "ghost"}
            className={`w-full justify-start h-12 px-4 cursor-pointer transition-all duration-200 ${
              activeItem === item.key 
                ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white hover:from-cyan-600 hover:to-blue-600 shadow-md' 
                : 'hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300'
            }`}
            onClick={() => handleNavigation(item.path)}
          >
            <div className="flex items-center justify-between w-full">
              <div className="flex items-center space-x-3">
                {item.icon}
                <span className="font-medium">
                  {language === 'ar' ? item.labelAR : item.label}
                </span>
              </div>
              {item.badge && (
                <Badge variant="secondary" className="ml-auto">
                  {item.badge}
                </Badge>
              )}
            </div>
          </Button>
        ))}
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        <div className="text-xs text-gray-500 dark:text-gray-400 text-center">
          <p>NBS LIMS v1.0</p>
          <p>{t('nav.footer', 'Laboratory Information Management System')}</p>
        </div>
      </div>
    </nav>
  );
};