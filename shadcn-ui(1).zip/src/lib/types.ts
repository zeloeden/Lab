// Core Entity Types for NBS LIMS

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  permissions: Permission[];
  preferences: UserPreferences;
  createdAt: Date;
  updatedAt: Date;
}

export interface UserPreferences {
  language: 'en' | 'ar';
  theme: 'light' | 'dark';
  timezone: string;
}

export interface Permission {
  resource: string;
  actions: ('create' | 'read' | 'update' | 'delete')[];
}

// Sample Management
export interface Sample {
  id: string;
  sampleNo: number; // Auto-generated, unique
  itemNameEN: string;
  itemNameAR: string;
  supplierId: string;
  batchNumber: string;
  dateOfSample: Date;
  purpose: Purpose;
  status: SampleStatus;
  approved: boolean;
  approvedTestId?: string;
  storageLocation: StorageLocation;
  customIdNo?: string;
  pricing: SamplePricing;
  createdBy: string;
  updatedBy: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface StorageLocation {
  cabinetNo: string;
  trayNo: string;
  refrigeratorShelf: string;
}

export interface SamplePricing {
  basePrice: number;
  currency: string;
  scalingPrices?: ScalingPrice[];
}

export interface ScalingPrice {
  tier: '25KG' | '50KG' | '100KG' | '200KG' | '500KG' | '1000KG';
  price: number;
}

// Supplier Management
export interface Supplier {
  id: string;
  name: string;
  code?: string;
  contactInfo: ContactInfo;
  address: Address;
  scalingEnabled: boolean;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface ContactInfo {
  phone?: string;
  email?: string;
  contactPerson?: string;
}

export interface Address {
  street: string;
  city: string;
  country: string;
  postalCode?: string;
}

// Test Management
export interface Test {
  id: string;
  sampleId: string;
  useType: UseType;
  date: Date;
  result: TestResult;
  approved: boolean;
  personalUseData?: PersonalUseTest;
  industrialData?: IndustrialTest;
  createdBy: string;
  updatedBy: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface PersonalUseTest {
  topNote: string;
  baseNote: string;
}

export interface IndustrialTest {
  formula: FormulaEntry[];
  formulaStatus: FormulaStatus;
}

export interface FormulaEntry {
  id: string;
  percentage: number;
  item: string; // Sample reference or free text
  notes?: string;
}

// Purchasing Workflow
export interface RequestedItem {
  id: string;
  itemName: string;
  sampleId?: string;
  quantity: number;
  unitOfMeasure: string;
  priority: Priority;
  purposeTag: PurposeTag;
  date: Date;
  status: RequestStatus;
  orderReference?: string;
  orderDate?: Date;
  notes?: string;
  createdBy: string;
  updatedBy: string;
  createdAt: Date;
  updatedAt: Date;
}

// Task Management
export interface Task {
  id: string;
  title: string;
  description: string;
  assignees: string[];
  dueDate?: Date;
  priority: TaskPriority;
  status: TaskStatus;
  comments: TaskComment[];
  attachments: TaskAttachment[];
  watchers: string[];
  subtasks: SubTask[];
  createdBy: string;
  updatedBy: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface TaskComment {
  id: string;
  content: string;
  authorId: string;
  createdAt: Date;
  parentId?: string; // For threaded comments
}

export interface TaskAttachment {
  id: string;
  filename: string;
  fileUrl: string;
  fileSize: number;
  mimeType: string;
  uploadedBy: string;
  uploadedAt: Date;
}

export interface SubTask {
  id: string;
  title: string;
  completed: boolean;
  assigneeId?: string;
  createdAt: Date;
}

// Audit Trail
export interface AuditLog {
  id: string;
  entityType: string;
  entityId: string;
  action: AuditAction;
  oldValues?: Record<string, unknown>;
  newValues?: Record<string, unknown>;
  userId: string;
  timestamp: Date;
  ipAddress?: string;
  userAgent?: string;
}

// Enums
export type UserRole = 'Admin' | 'LabLead' | 'Technician' | 'Purchasing' | 'Viewer';
export type Purpose = 'Personal Use' | 'Industrial';
export type SampleStatus = 'Pending' | 'Testing' | 'Rejected' | 'Accepted';
export type UseType = 'Personal Use' | 'Industrial';
export type TestResult = 'Accepted' | 'Rejected' | 'Rework' | 'Retest';
export type FormulaStatus = 'Success' | 'Rejected' | 'Retest';
export type Priority = 'Air' | 'Sea' | 'Land';
export type PurposeTag = 'Requested' | 'To fill the container with';
export type RequestStatus = 'Requested' | 'Sent to Ordering' | 'Ordered';
export type TaskPriority = 'Low' | 'Medium' | 'High' | 'Critical';
export type TaskStatus = 'Backlog' | 'In Progress' | 'Waiting' | 'Done';
export type AuditAction = 'CREATE' | 'UPDATE' | 'DELETE' | 'APPROVE' | 'REJECT';

// Analytics Types
export interface KPIData {
  acceptedSamples30Days: number;
  acceptedSamples90Days: number;
  rejectedPercentage: number;
  retestPercentage: number;
  reworkPercentage: number;
  requestedVsOrdered: {
    requested: number;
    ordered: number;
  };
}

export interface SupplierPerformance {
  supplierId: string;
  supplierName: string;
  acceptanceRate: number;
  averageLeadTime: number;
  totalSamples: number;
}

// Form Types
export interface CreateSampleRequest {
  itemNameEN: string;
  itemNameAR: string;
  supplierId: string;
  batchNumber: string;
  dateOfSample: Date;
  purpose: Purpose;
  storageLocation: StorageLocation;
  customIdNo?: string;
  pricing: SamplePricing;
}

export interface CreateTestRequest {
  sampleId: string;
  useType: UseType;
  date: Date;
  personalUseData?: PersonalUseTest;
  industrialData?: IndustrialTest;
}

export interface CreateRequestRequest {
  itemName: string;
  sampleId?: string;
  quantity: number;
  unitOfMeasure: string;
  priority: Priority;
  purposeTag: PurposeTag;
  date: Date;
  notes?: string;
}

// Utility Types
export interface FilterOptions {
  [key: string]: unknown;
}

export interface PaginationConfig {
  page: number;
  pageSize: number;
  total: number;
}

export interface SortConfig {
  field: string;
  direction: 'asc' | 'desc';
}

export interface TableColumn<T> {
  key: keyof T;
  title: string;
  titleAR?: string;
  width?: number;
  sortable?: boolean;
  filterable?: boolean;
  render?: (value: unknown, item: T) => React.ReactNode;
}

export interface ImportResult {
  success: number;
  failed: number;
  errors: string[];
}

// Role Permissions Matrix
export const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  Admin: [
    { resource: 'samples', actions: ['create', 'read', 'update', 'delete'] },
    { resource: 'tests', actions: ['create', 'read', 'update', 'delete'] },
    { resource: 'suppliers', actions: ['create', 'read', 'update', 'delete'] },
    { resource: 'purchasing', actions: ['create', 'read', 'update', 'delete'] },
    { resource: 'tasks', actions: ['create', 'read', 'update', 'delete'] },
    { resource: 'analytics', actions: ['read'] },
    { resource: 'settings', actions: ['create', 'read', 'update', 'delete'] },
    { resource: 'users', actions: ['create', 'read', 'update', 'delete'] },
  ],
  LabLead: [
    { resource: 'samples', actions: ['create', 'read', 'update', 'delete'] },
    { resource: 'tests', actions: ['create', 'read', 'update', 'delete'] },
    { resource: 'suppliers', actions: ['read'] },
    { resource: 'purchasing', actions: ['read'] },
    { resource: 'tasks', actions: ['read', 'update'] },
    { resource: 'analytics', actions: ['read'] },
  ],
  Technician: [
    { resource: 'samples', actions: ['read'] },
    { resource: 'tests', actions: ['create', 'update'] },
    { resource: 'suppliers', actions: ['read'] },
    { resource: 'purchasing', actions: ['create'] },
    { resource: 'tasks', actions: ['read', 'update'] },
  ],
  Purchasing: [
    { resource: 'samples', actions: ['read'] },
    { resource: 'tests', actions: ['read'] },
    { resource: 'suppliers', actions: ['create', 'read', 'update', 'delete'] },
    { resource: 'purchasing', actions: ['create', 'read', 'update', 'delete'] },
    { resource: 'tasks', actions: ['read', 'update'] },
    { resource: 'analytics', actions: ['read'] },
  ],
  Viewer: [
    { resource: 'samples', actions: ['read'] },
    { resource: 'tests', actions: ['read'] },
    { resource: 'suppliers', actions: ['read'] },
    { resource: 'purchasing', actions: ['read'] },
    { resource: 'analytics', actions: ['read'] },
  ],
};