import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/contexts/I18nContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Area,
  AreaChart
} from 'recharts';
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  Users, 
  Package, 
  TestTube,
  ShoppingCart,
  CheckCircle,
  Clock,
  AlertTriangle,
  Calendar,
  Target,
  Zap,
  Award,
  Filter,
  Download,
  RefreshCw
} from 'lucide-react';

// Mock analytics data
const mockAnalyticsData = {
  overview: {
    totalSamples: 156,
    activeSamples: 23,
    completedTests: 89,
    pendingTests: 12,
    totalSuppliers: 15,
    activeOrders: 8,
    monthlyGrowth: 12.5,
    testSuccessRate: 94.2
  },
  sampleTrends: [
    { month: 'Jan', samples: 45, tests: 38, approved: 35 },
    { month: 'Feb', samples: 52, tests: 47, approved: 44 },
    { month: 'Mar', samples: 48, tests: 45, approved: 41 },
    { month: 'Apr', samples: 61, tests: 58, approved: 54 },
    { month: 'May', samples: 55, tests: 52, approved: 49 },
    { month: 'Jun', samples: 67, tests: 63, approved: 59 }
  ],
  testResults: [
    { name: 'Passed', value: 142, color: '#10b981' },
    { name: 'Failed', value: 18, color: '#ef4444' },
    { name: 'Pending', value: 12, color: '#f59e0b' },
    { name: 'In Progress', value: 8, color: '#3b82f6' }
  ],
  supplierPerformance: [
    { name: 'Supplier A', orders: 25, onTime: 23, quality: 95 },
    { name: 'Supplier B', orders: 18, onTime: 16, quality: 89 },
    { name: 'Supplier C', orders: 22, onTime: 21, quality: 96 },
    { name: 'Supplier D', orders: 15, onTime: 13, quality: 87 },
    { name: 'Supplier E', orders: 12, onTime: 11, quality: 92 }
  ],
  weeklyActivity: [
    { day: 'Mon', samples: 12, tests: 8, orders: 3 },
    { day: 'Tue', samples: 15, tests: 11, orders: 2 },
    { day: 'Wed', samples: 18, tests: 14, orders: 4 },
    { day: 'Thu', samples: 14, tests: 12, orders: 1 },
    { day: 'Fri', samples: 16, tests: 13, orders: 3 },
    { day: 'Sat', samples: 8, tests: 5, orders: 1 },
    { day: 'Sun', samples: 6, tests: 4, orders: 0 }
  ],
  recentActivity: [
    { id: 1, type: 'sample', action: 'Sample #156 created', user: 'Lab Tech', time: '2 hours ago' },
    { id: 2, type: 'test', action: 'Test approved for Sample #155', user: 'Lab Lead', time: '3 hours ago' },
    { id: 3, type: 'order', action: 'Purchase order PO-2024-008 placed', user: 'Admin', time: '5 hours ago' },
    { id: 4, type: 'sample', action: 'Sample #154 status updated', user: 'Lab Tech', time: '6 hours ago' },
    { id: 5, type: 'test', action: 'Test failed for Sample #153', user: 'Lab Lead', time: '8 hours ago' }
  ]
};

export const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const { t, language } = useI18n();
  const [activeTab, setActiveTab] = useState('overview');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [data, setData] = useState(mockAnalyticsData);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    // Simulate data refresh
    setTimeout(() => {
      setIsRefreshing(false);
    }, 1500);
  };

  const StatCard = ({ title, value, change, icon, color = 'blue' }: {
    title: string;
    value: string | number;
    change?: number;
    icon: React.ReactNode;
    color?: string;
  }) => (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className="text-3xl font-bold">{value}</p>
            {change !== undefined && (
              <div className={`flex items-center mt-2 ${change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {change >= 0 ? <TrendingUp className="h-4 w-4 mr-1" /> : <TrendingDown className="h-4 w-4 mr-1" />}
                <span className="text-sm font-medium">{Math.abs(change)}%</span>
              </div>
            )}
          </div>
          <div className={`p-3 rounded-full bg-${color}-100`}>
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Analytics Dashboard</h1>
          <p className="text-gray-600">Laboratory management insights and performance metrics</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={handleRefresh} disabled={isRefreshing}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Analytics Tabs - Fixed Navigation */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview" className="flex items-center">
            <Activity className="h-4 w-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="samples" className="flex items-center">
            <Package className="h-4 w-4 mr-2" />
            Samples
          </TabsTrigger>
          <TabsTrigger value="tests" className="flex items-center">
            <TestTube className="h-4 w-4 mr-2" />
            Tests
          </TabsTrigger>
          <TabsTrigger value="suppliers" className="flex items-center">
            <Users className="h-4 w-4 mr-2" />
            Suppliers
          </TabsTrigger>
          <TabsTrigger value="activity" className="flex items-center">
            <Zap className="h-4 w-4 mr-2" />
            Activity
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard
              title="Total Samples"
              value={data.overview.totalSamples}
              change={data.overview.monthlyGrowth}
              icon={<Package className="h-6 w-6 text-blue-600" />}
              color="blue"
            />
            <StatCard
              title="Active Tests"
              value={data.overview.pendingTests}
              icon={<TestTube className="h-6 w-6 text-purple-600" />}
              color="purple"
            />
            <StatCard
              title="Success Rate"
              value={`${data.overview.testSuccessRate}%`}
              change={2.1}
              icon={<Award className="h-6 w-6 text-green-600" />}
              color="green"
            />
            <StatCard
              title="Active Orders"
              value={data.overview.activeOrders}
              icon={<ShoppingCart className="h-6 w-6 text-orange-600" />}
              color="orange"
            />
          </div>

          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Sample Trends</CardTitle>
                <CardDescription>Monthly sample processing and approval rates</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={data.sampleTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Area type="monotone" dataKey="samples" stackId="1" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.6} />
                    <Area type="monotone" dataKey="approved" stackId="2" stroke="#10b981" fill="#10b981" fillOpacity={0.6} />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Test Results Distribution</CardTitle>
                <CardDescription>Current test status breakdown</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={data.testResults}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {data.testResults.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Samples Tab */}
        <TabsContent value="samples" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Sample Processing Timeline</CardTitle>
                <CardDescription>Daily sample intake and processing</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={data.weeklyActivity}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="samples" stroke="#3b82f6" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Sample Status</CardTitle>
                <CardDescription>Current sample distribution</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Active Samples</span>
                  <Badge className="bg-blue-100 text-blue-800">{data.overview.activeSamples}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Completed</span>
                  <Badge className="bg-green-100 text-green-800">{data.overview.completedTests}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Pending</span>
                  <Badge className="bg-yellow-100 text-yellow-800">{data.overview.pendingTests}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Total Processed</span>
                  <Badge variant="outline">{data.overview.totalSamples}</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Tests Tab */}
        <TabsContent value="tests" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Test Performance</CardTitle>
                <CardDescription>Monthly test completion and success rates</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={data.sampleTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="tests" fill="#3b82f6" />
                    <Bar dataKey="approved" fill="#10b981" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Test Efficiency Metrics</CardTitle>
                <CardDescription>Key performance indicators</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Success Rate</span>
                    <span className="text-sm text-green-600 font-bold">{data.overview.testSuccessRate}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-green-600 h-2 rounded-full" 
                      style={{ width: `${data.overview.testSuccessRate}%` }}
                    ></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Completion Rate</span>
                    <span className="text-sm text-blue-600 font-bold">87%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '87%' }}></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">On-Time Delivery</span>
                    <span className="text-sm text-purple-600 font-bold">92%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-purple-600 h-2 rounded-full" style={{ width: '92%' }}></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Suppliers Tab */}
        <TabsContent value="suppliers" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Supplier Performance</CardTitle>
              <CardDescription>Order fulfillment and quality metrics by supplier</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={data.supplierPerformance} layout="horizontal">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="name" type="category" width={80} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="orders" fill="#3b82f6" name="Total Orders" />
                  <Bar dataKey="onTime" fill="#10b981" name="On-Time Delivery" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Activity Tab */}
        <TabsContent value="activity" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Weekly Activity</CardTitle>
                <CardDescription>Daily operations breakdown</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={data.weeklyActivity}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="samples" fill="#3b82f6" name="Samples" />
                    <Bar dataKey="tests" fill="#10b981" name="Tests" />
                    <Bar dataKey="orders" fill="#f59e0b" name="Orders" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Latest system activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {data.recentActivity.map((activity) => (
                    <div key={activity.id} className="flex items-start space-x-3 p-3 rounded-lg bg-gray-50">
                      <div className={`p-2 rounded-full ${
                        activity.type === 'sample' ? 'bg-blue-100' :
                        activity.type === 'test' ? 'bg-green-100' : 'bg-orange-100'
                      }`}>
                        {activity.type === 'sample' && <Package className="h-4 w-4 text-blue-600" />}
                        {activity.type === 'test' && <TestTube className="h-4 w-4 text-green-600" />}
                        {activity.type === 'order' && <ShoppingCart className="h-4 w-4 text-orange-600" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900">{activity.action}</p>
                        <p className="text-xs text-gray-500">by {activity.user} • {activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};