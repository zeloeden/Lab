import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { Plus, Search, Filter, Edit, Trash2, Eye, Package, Clock, CheckCircle, MapPin } from 'lucide-react';

// Mock services
const sampleService = {
  getAllSamples: async () => {
    const stored = localStorage.getItem('nbslims_samples');
    return stored ? JSON.parse(stored) : [];
  },
  createSample: async (data: any) => {
    const samples = await sampleService.getAllSamples();
    const newSample = {
      ...data,
      id: `sample-${Date.now()}`,
      sampleNo: samples.length + 1,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    const updated = [newSample, ...samples];
    localStorage.setItem('nbslims_samples', JSON.stringify(updated));
    return newSample;
  },
  updateSample: async (id: string, data: any) => {
    const samples = await sampleService.getAllSamples();
    const updated = samples.map((s: any) => s.id === id ? { ...s, ...data, updatedAt: new Date() } : s);
    localStorage.setItem('nbslims_samples', JSON.stringify(updated));
    return updated.find((s: any) => s.id === id);
  }
};

const supplierService = {
  getAllSuppliers: async () => {
    return [
      { id: 'sup-1', name: 'Chemical Supplies Co.' },
      { id: 'sup-2', name: 'Lab Equipment Ltd.' },
      { id: 'sup-3', name: 'Scientific Materials Inc.' }
    ];
  }
};

interface EnhancedSample {
  id: string;
  sampleNo: number;
  itemNameEN: string;
  itemNameAR?: string;
  supplierId: string;
  category?: string;
  quantity: number;
  unit: string;
  status: 'Pending' | 'Testing' | 'Rejected' | 'Accepted';
  createdBy?: string;
  createdAt?: Date;
  updatedAt?: Date;
  storageLocation?: {
    rackArea: string;
    shelfLevel: string;
    position?: string;
    zone?: string;
    temperature?: 'ambient' | 'refrigerated' | 'frozen';
    notes?: string;
  };
}

export const Samples: React.FC = () => {
  const { user, hasPermission } = useAuth();
  
  const [samples, setSamples] = useState<EnhancedSample[]>([]);
  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [locationFilter, setLocationFilter] = useState<string>('all');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedSample, setSelectedSample] = useState<EnhancedSample | null>(null);

  // Form state for both create and edit
  const [formData, setFormData] = useState({
    itemNameEN: '',
    itemNameAR: '',
    supplierId: '',
    category: '',
    quantity: 0,
    unit: 'kg',
    status: 'Pending' as const,
    // Storage location fields
    rackArea: '',
    shelfLevel: '',
    position: '',
    zone: '',
    temperature: 'ambient' as const,
    locationNotes: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [samplesData, suppliersData] = await Promise.all([
        sampleService.getAllSamples(),
        supplierService.getAllSuppliers()
      ]);
      
      const storedSamples = localStorage.getItem('nbslims_enhanced_samples');
      if (storedSamples) {
        setSamples(JSON.parse(storedSamples));
      } else {
        const enhancedSamples = samplesData.map((sample: any) => ({
          ...sample,
          storageLocation: undefined
        }));
        setSamples(enhancedSamples);
        localStorage.setItem('nbslims_enhanced_samples', JSON.stringify(enhancedSamples));
      }
      
      setSuppliers(suppliersData);
    } catch (error) {
      toast.error('Failed to load data');
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveSamples = useCallback((updatedSamples: EnhancedSample[]) => {
    setSamples(updatedSamples);
    localStorage.setItem('nbslims_enhanced_samples', JSON.stringify(updatedSamples));
  }, []);

  const resetForm = useCallback(() => {
    setFormData({
      itemNameEN: '',
      itemNameAR: '',
      supplierId: '',
      category: '',
      quantity: 0,
      unit: 'kg',
      status: 'Pending',
      rackArea: '',
      shelfLevel: '',
      position: '',
      zone: '',
      temperature: 'ambient',
      locationNotes: ''
    });
  }, []);

  const handleCreateSample = useCallback(async () => {
    if (!formData.itemNameEN || !formData.supplierId) {
      toast.error('Please fill in required fields');
      return;
    }

    try {
      const sampleData = {
        itemNameEN: formData.itemNameEN,
        itemNameAR: formData.itemNameAR,
        supplierId: formData.supplierId,
        category: formData.category,
        quantity: formData.quantity,
        unit: formData.unit,
        status: formData.status,
        createdBy: user?.id || 'unknown'
      };

      const newSample = await sampleService.createSample(sampleData);
      
      // Add storage location if provided
      let storageLocation = undefined;
      if (formData.rackArea.trim() || formData.shelfLevel.trim()) {
        storageLocation = {
          rackArea: formData.rackArea.trim(),
          shelfLevel: formData.shelfLevel.trim(),
          position: formData.position.trim(),
          zone: formData.zone.trim(),
          temperature: formData.temperature,
          notes: formData.locationNotes.trim()
        };
      }

      const enhancedSample: EnhancedSample = {
        ...newSample,
        storageLocation
      };
      
      const updatedSamples = [enhancedSample, ...samples];
      saveSamples(updatedSamples);
      setIsCreateDialogOpen(false);
      resetForm();
      toast.success('Sample created successfully');
    } catch (error) {
      toast.error('Failed to create sample');
      console.error('Error creating sample:', error);
    }
  }, [formData, user?.id, samples, saveSamples, resetForm]);

  const handleEditClick = useCallback((sample: EnhancedSample) => {
    setSelectedSample(sample);
    setFormData({
      itemNameEN: sample.itemNameEN,
      itemNameAR: sample.itemNameAR || '',
      supplierId: sample.supplierId,
      category: sample.category || '',
      quantity: sample.quantity,
      unit: sample.unit,
      status: sample.status,
      rackArea: sample.storageLocation?.rackArea || '',
      shelfLevel: sample.storageLocation?.shelfLevel || '',
      position: sample.storageLocation?.position || '',
      zone: sample.storageLocation?.zone || '',
      temperature: sample.storageLocation?.temperature || 'ambient',
      locationNotes: sample.storageLocation?.notes || ''
    });
    setIsEditDialogOpen(true);
  }, []);

  const handleUpdateSample = useCallback(async () => {
    if (!selectedSample || !formData.itemNameEN || !formData.supplierId) {
      toast.error('Please fill in required fields');
      return;
    }

    try {
      // Create storage location if any location field is provided
      let storageLocation = undefined;
      if (formData.rackArea.trim() || formData.shelfLevel.trim() || formData.position.trim() || formData.zone.trim() || formData.locationNotes.trim()) {
        storageLocation = {
          rackArea: formData.rackArea.trim(),
          shelfLevel: formData.shelfLevel.trim(),
          position: formData.position.trim(),
          zone: formData.zone.trim(),
          temperature: formData.temperature,
          notes: formData.locationNotes.trim()
        };
      }

      const updatedSamples = samples.map(s => 
        s.id === selectedSample.id 
          ? { 
              ...s, 
              itemNameEN: formData.itemNameEN,
              itemNameAR: formData.itemNameAR,
              supplierId: formData.supplierId,
              category: formData.category,
              quantity: formData.quantity,
              unit: formData.unit,
              status: formData.status,
              storageLocation,
              updatedAt: new Date()
            }
          : s
      );
      
      saveSamples(updatedSamples);
      setIsEditDialogOpen(false);
      setSelectedSample(null);
      resetForm();
      toast.success('Sample updated successfully');
    } catch (error) {
      toast.error('Failed to update sample');
      console.error('Error updating sample:', error);
    }
  }, [selectedSample, formData, samples, saveSamples, resetForm]);

  const filteredSamples = samples.filter(sample => {
    const matchesSearch = sample.itemNameEN.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         sample.itemNameAR?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         sample.sampleNo.toString().includes(searchTerm) ||
                         sample.storageLocation?.rackArea.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         sample.storageLocation?.shelfLevel.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || sample.status === statusFilter;
    
    const matchesLocation = locationFilter === 'all' || 
                           (locationFilter === 'stored' && sample.storageLocation) ||
                           (locationFilter === 'unstored' && !sample.storageLocation);
    
    return matchesSearch && matchesStatus && matchesLocation;
  });

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'Pending': return 'bg-yellow-100 text-yellow-800';
      case 'Testing': return 'bg-blue-100 text-blue-800';
      case 'Accepted': return 'bg-green-100 text-green-800';
      case 'Rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTemperatureColor = (temp: string) => {
    switch (temp) {
      case 'frozen': return 'bg-blue-100 text-blue-800';
      case 'refrigerated': return 'bg-cyan-100 text-cyan-800';
      case 'ambient': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatStorageLocation = (location: EnhancedSample['storageLocation']) => {
    if (!location || (!location.rackArea && !location.shelfLevel)) return 'Not assigned';
    
    const parts = [];
    if (location.rackArea) parts.push(location.rackArea);
    if (location.shelfLevel) parts.push(location.shelfLevel);
    if (location.position) parts.push(location.position);
    
    let formatted = parts.join('-');
    if (location.zone) formatted += ` (${location.zone})`;
    
    return formatted;
  };

  const uniqueRacks = [...new Set(samples
    .filter(s => s.storageLocation?.rackArea)
    .map(s => s.storageLocation!.rackArea)
  )].sort();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Package className="h-8 w-8 animate-spin mx-auto mb-2" />
          <p>Loading samples...</p>
        </div>
      </div>
    );
  }

  const renderSampleForm = (isEdit = false) => (
    <div className="space-y-6">
      {/* Basic Sample Information */}
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="itemNameEN">Item Name (EN) *</Label>
            <Input
              id="itemNameEN"
              value={formData.itemNameEN}
              onChange={(e) => setFormData(prev => ({ ...prev, itemNameEN: e.target.value }))}
              placeholder="Enter item name in English"
            />
          </div>
          <div>
            <Label htmlFor="itemNameAR">Item Name (AR)</Label>
            <Input
              id="itemNameAR"
              value={formData.itemNameAR}
              onChange={(e) => setFormData(prev => ({ ...prev, itemNameAR: e.target.value }))}
              placeholder="Enter item name in Arabic"
              dir="rtl"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="supplier">Supplier *</Label>
            <Select value={formData.supplierId} onValueChange={(value) => setFormData(prev => ({ ...prev, supplierId: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Select supplier" />
              </SelectTrigger>
              <SelectContent>
                {suppliers.map(supplier => (
                  <SelectItem key={supplier.id} value={supplier.id}>
                    {supplier.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="category">Category</Label>
            <Input
              id="category"
              value={formData.category}
              onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
              placeholder="e.g., Raw Materials, Chemicals"
            />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div>
            <Label htmlFor="quantity">Quantity</Label>
            <Input
              id="quantity"
              type="number"
              step="0.01"
              value={formData.quantity}
              onChange={(e) => setFormData(prev => ({ ...prev, quantity: parseFloat(e.target.value) || 0 }))}
              placeholder="0.00"
            />
          </div>
          <div>
            <Label htmlFor="unit">Unit</Label>
            <Select value={formData.unit} onValueChange={(value) => setFormData(prev => ({ ...prev, unit: value }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="kg">Kilogram (kg)</SelectItem>
                <SelectItem value="g">Gram (g)</SelectItem>
                <SelectItem value="L">Liter (L)</SelectItem>
                <SelectItem value="mL">Milliliter (mL)</SelectItem>
                <SelectItem value="pcs">Pieces (pcs)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="status">Status</Label>
            <Select value={formData.status} onValueChange={(value: any) => setFormData(prev => ({ ...prev, status: value }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Pending">Pending</SelectItem>
                <SelectItem value="Testing">Testing</SelectItem>
                <SelectItem value="Accepted">Accepted</SelectItem>
                <SelectItem value="Rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <Separator />

      {/* Storage Location Section */}
      <div className="space-y-4">
        <div className="flex items-center space-x-2">
          <MapPin className="h-5 w-5 text-purple-500" />
          <Label className="text-base font-medium">Storage Location (Optional)</Label>
        </div>
        <p className="text-sm text-gray-500">
          Specify where this sample will be stored in the laboratory
        </p>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="rackArea">Rack/Storage Area</Label>
            <Input
              id="rackArea"
              value={formData.rackArea}
              onChange={(e) => setFormData(prev => ({ ...prev, rackArea: e.target.value }))}
              placeholder="e.g., Rack A, Storage Room 1"
            />
          </div>
          <div>
            <Label htmlFor="shelfLevel">Shelf/Level</Label>
            <Input
              id="shelfLevel"
              value={formData.shelfLevel}
              onChange={(e) => setFormData(prev => ({ ...prev, shelfLevel: e.target.value }))}
              placeholder="e.g., Shelf 1, Level 2"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="position">Position/Slot</Label>
            <Input
              id="position"
              value={formData.position}
              onChange={(e) => setFormData(prev => ({ ...prev, position: e.target.value }))}
              placeholder="e.g., A1, Position 5"
            />
          </div>
          <div>
            <Label htmlFor="zone">Zone/Section</Label>
            <Input
              id="zone"
              value={formData.zone}
              onChange={(e) => setFormData(prev => ({ ...prev, zone: e.target.value }))}
              placeholder="e.g., Lab A, Cold Storage"
            />
          </div>
        </div>

        <div>
          <Label htmlFor="temperature">Temperature Requirement</Label>
          <Select value={formData.temperature} onValueChange={(value: any) => setFormData(prev => ({ ...prev, temperature: value }))}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ambient">Ambient (Room Temperature)</SelectItem>
              <SelectItem value="refrigerated">Refrigerated (2-8°C)</SelectItem>
              <SelectItem value="frozen">Frozen (-18°C or below)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="locationNotes">Storage Notes</Label>
          <Textarea
            id="locationNotes"
            value={formData.locationNotes}
            onChange={(e) => setFormData(prev => ({ ...prev, locationNotes: e.target.value }))}
            placeholder="Additional storage notes or special instructions"
            rows={3}
          />
        </div>
      </div>

      <div className="flex justify-end space-x-2 pt-4">
        <Button 
          variant="outline" 
          onClick={() => {
            if (isEdit) {
              setIsEditDialogOpen(false);
            } else {
              setIsCreateDialogOpen(false);
            }
            resetForm();
          }}
        >
          Cancel
        </Button>
        <Button onClick={isEdit ? handleUpdateSample : handleCreateSample}>
          {isEdit ? 'Update Sample' : 'Create Sample'}
        </Button>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Sample Management</h1>
          <p className="text-gray-600">Track and manage laboratory samples with integrated storage locations</p>
        </div>
        {hasPermission('samples', 'create') && (
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Sample
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create New Sample</DialogTitle>
                <DialogDescription>
                  Add a new sample with storage location information
                </DialogDescription>
              </DialogHeader>
              {renderSampleForm(false)}
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Package className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-sm text-gray-600">Total</p>
                <p className="text-2xl font-bold">{samples.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-yellow-500" />
              <div>
                <p className="text-sm text-gray-600">Pending</p>
                <p className="text-2xl font-bold">{samples.filter(s => s.status === 'Pending').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <div className="w-5 h-5 bg-blue-500 rounded-full" />
              <div>
                <p className="text-sm text-gray-600">Testing</p>
                <p className="text-2xl font-bold">{samples.filter(s => s.status === 'Testing').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-sm text-gray-600">Accepted</p>
                <p className="text-2xl font-bold">{samples.filter(s => s.status === 'Accepted').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <MapPin className="h-5 w-5 text-purple-500" />
              <div>
                <p className="text-sm text-gray-600">Stored</p>
                <p className="text-2xl font-bold">{samples.filter(s => s.storageLocation).length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search samples by name, ID, or storage location..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Pending">Pending</SelectItem>
                <SelectItem value="Testing">Testing</SelectItem>
                <SelectItem value="Accepted">Accepted</SelectItem>
                <SelectItem value="Rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
            <Select value={locationFilter} onValueChange={setLocationFilter}>
              <SelectTrigger className="w-48">
                <MapPin className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Locations</SelectItem>
                <SelectItem value="stored">With Storage</SelectItem>
                <SelectItem value="unstored">No Storage</SelectItem>
                {uniqueRacks.map(rack => (
                  <SelectItem key={rack} value={rack}>{rack}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Samples ({filteredSamples.length})</CardTitle>
          <CardDescription>
            Manage laboratory samples with integrated storage location tracking
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Sample #</TableHead>
                <TableHead>Item Name</TableHead>
                <TableHead>Supplier</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Storage Location</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created Date</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSamples.map((sample) => {
                const supplier = suppliers.find(s => s.id === sample.supplierId);
                return (
                  <TableRow key={sample.id}>
                    <TableCell className="font-medium">#{sample.sampleNo}</TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium">{sample.itemNameEN}</p>
                        {sample.itemNameAR && (
                          <p className="text-sm text-gray-500" dir="rtl">{sample.itemNameAR}</p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{supplier?.name || 'Unknown'}</TableCell>
                    <TableCell>{sample.quantity} {sample.unit}</TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <MapPin className="h-3 w-3 text-gray-400" />
                          <span className="text-sm font-medium">
                            {formatStorageLocation(sample.storageLocation)}
                          </span>
                        </div>
                        {sample.storageLocation?.temperature && (
                          <Badge className={getTemperatureColor(sample.storageLocation.temperature)} size="sm">
                            {sample.storageLocation.temperature}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusBadgeColor(sample.status)}>
                        {sample.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {sample.createdAt ? new Date(sample.createdAt).toLocaleDateString() : 'N/A'}
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                        {hasPermission('samples', 'update') && (
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleEditClick(sample)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        )}
                        {hasPermission('samples', 'delete') && (
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit Sample Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Sample</DialogTitle>
            <DialogDescription>
              Update sample information and storage location
            </DialogDescription>
          </DialogHeader>
          {renderSampleForm(true)}
        </DialogContent>
      </Dialog>
    </div>
  );
};