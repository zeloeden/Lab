import React, { useState, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/contexts/I18nContext';
import { useTheme } from '@/contexts/ThemeContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { UserAvatar } from '@/components/UserAvatar';
import { SoundSettings } from '@/components/SoundSettings';
import { toast } from 'sonner';
import { 
  Settings as SettingsIcon, 
  User, 
  Globe, 
  Palette, 
  Bell, 
  Shield, 
  Camera,
  Upload,
  Trash2,
  Save,
  Volume2
} from 'lucide-react';

export function Settings() {
  const { user, updateUserProfile, uploadProfilePhoto, removeProfilePhoto } = useAuth();
  const { language, setLanguage, t } = useI18n();
  const { theme, setTheme } = useTheme();
  
  const [isUploading, setIsUploading] = useState(false);
  const [profileData, setProfileData] = useState({
    fullName: user?.fullName || '',
    email: user?.email || '',
    username: user?.username || ''
  });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleProfileUpdate = () => {
    updateUserProfile(profileData);
    toast.success('Profile updated successfully');
  };

  const handlePhotoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const success = await uploadProfilePhoto(file);
      if (success) {
        toast.success('Profile photo updated successfully');
      } else {
        toast.error('Failed to upload profile photo');
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to upload profile photo');
    } finally {
      setIsUploading(false);
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleRemovePhoto = () => {
    removeProfilePhoto();
    toast.success('Profile photo removed');
  };

  const handleLanguageChange = (newLanguage: string) => {
    setLanguage(newLanguage as 'en' | 'ar');
    toast.success(newLanguage === 'en' ? 'Language changed to English' : 'تم تغيير اللغة إلى العربية');
  };

  const handleThemeChange = (newTheme: string) => {
    setTheme(newTheme as 'light' | 'dark' | 'system');
    toast.success(`Theme changed to ${newTheme}`);
  };

  if (!user) return null;

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2">
        <SettingsIcon className="h-6 w-6" />
        <h1 className="text-2xl font-bold">{t('settings.title', 'Settings')}</h1>
      </div>

      {/* Profile Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <User className="h-5 w-5" />
            <span>{t('settings.profile.title', 'Profile Settings')}</span>
          </CardTitle>
          <CardDescription>
            {t('settings.profile.description', 'Manage your personal information and profile photo.')}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Profile Photo Section */}
          <div className="space-y-4">
            <Label className="text-base font-medium">Profile Photo</Label>
            <div className="flex items-center space-x-6">
              <UserAvatar user={user} size="xl" />
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading}
                    className="flex items-center space-x-2"
                  >
                    {isUploading ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                        <span>Uploading...</span>
                      </>
                    ) : (
                      <>
                        <Camera className="h-4 w-4" />
                        <span>Change Photo</span>
                      </>
                    )}
                  </Button>
                  {user.profilePhoto && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleRemovePhoto}
                      className="flex items-center space-x-2 text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                      <span>Remove</span>
                    </Button>
                  )}
                </div>
                <p className="text-xs text-gray-500">
                  JPG, PNG, GIF or WebP. Max file size 5MB.
                </p>
                {user.profilePhotoName && (
                  <p className="text-xs text-gray-400">
                    Current: {user.profilePhotoName}
                  </p>
                )}
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/gif,image/webp"
                onChange={handlePhotoUpload}
                className="hidden"
              />
            </div>
          </div>

          <Separator />

          {/* Basic Information */}
          <div className="space-y-4">
            <Label className="text-base font-medium">Basic Information</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name</Label>
                <Input
                  id="fullName"
                  value={profileData.fullName}
                  onChange={(e) => setProfileData(prev => ({ ...prev, fullName: e.target.value }))}
                  placeholder="Enter your full name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  value={profileData.username}
                  onChange={(e) => setProfileData(prev => ({ ...prev, username: e.target.value }))}
                  placeholder="Enter your username"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={profileData.email}
                  onChange={(e) => setProfileData(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="Enter your email"
                />
              </div>
              <div className="space-y-2">
                <Label>Role</Label>
                <div className="flex items-center h-10">
                  <Badge variant="outline" className="px-3 py-1">
                    {user.role}
                  </Badge>
                </div>
              </div>
            </div>
            <div className="flex justify-end">
              <Button onClick={handleProfileUpdate} className="flex items-center space-x-2">
                <Save className="h-4 w-4" />
                <span>Save Changes</span>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sound Settings */}
      <SoundSettings />

      {/* Language & Region */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Globe className="h-5 w-5" />
            <span>{t('settings.language.title', 'Language & Region')}</span>
          </CardTitle>
          <CardDescription>
            {t('settings.language.description', 'Choose your preferred language and regional settings.')}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="language">{t('settings.language.label', 'Language')}</Label>
            <Select value={language} onValueChange={handleLanguageChange}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="ar">العربية (Arabic)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Appearance */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Palette className="h-5 w-5" />
            <span>{t('settings.appearance.title', 'Appearance')}</span>
          </CardTitle>
          <CardDescription>
            {t('settings.appearance.description', 'Customize the look and feel of the application.')}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="theme">{t('settings.appearance.theme', 'Theme')}</Label>
            <Select value={theme} onValueChange={handleThemeChange}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="light">Light</SelectItem>
                <SelectItem value="dark">Dark</SelectItem>
                <SelectItem value="system">System</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Security */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5" />
            <span>{t('settings.security.title', 'Security')}</span>
          </CardTitle>
          <CardDescription>
            {t('settings.security.description', 'Manage your account security settings.')}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Account Status</Label>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                Active
              </Badge>
              <span className="text-sm text-gray-500">Your account is active and secure</span>
            </div>
          </div>
          <div className="space-y-2">
            <Label>Last Login</Label>
            <p className="text-sm text-gray-600">Today at 2:30 PM</p>
          </div>
          <div className="pt-2">
            <Button variant="outline" className="text-blue-600 hover:text-blue-700">
              Change Password
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}