import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { 
  Users, 
  Plus, 
  Edit, 
  Trash2, 
  Mail, 
  Phone, 
  MapPin, 
  Building, 
  Star,
  DollarSign,
  Package,
  Calendar
} from 'lucide-react';

interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  country: string;
  status: 'active' | 'inactive';
  rating: number;
  totalOrders: number;
  lastOrderDate: Date;
  categories: string[];
  paymentTerms: string;
  deliveryTime: string;
  scalingPricing: {
    enabled: boolean;
    tiers: {
      minQuantity: number;
      maxQuantity: number;
      discount: number;
    }[];
  };
}

const initialSuppliers: Supplier[] = [
  {
    id: '1',
    name: 'Lab Equipment Co.',
    contactPerson: 'John Smith',
    email: 'john@labequipment.com',
    phone: '+1-555-0101',
    address: '123 Science Ave',
    city: 'Boston',
    country: 'USA',
    status: 'active',
    rating: 4.5,
    totalOrders: 45,
    lastOrderDate: new Date('2024-01-15'),
    categories: ['Equipment', 'Glassware'],
    paymentTerms: 'Net 30',
    deliveryTime: '5-7 days',
    scalingPricing: {
      enabled: true,
      tiers: [
        { minQuantity: 1, maxQuantity: 10, discount: 0 },
        { minQuantity: 11, maxQuantity: 50, discount: 5 },
        { minQuantity: 51, maxQuantity: 999, discount: 10 }
      ]
    }
  },
  {
    id: '2',
    name: 'Chemical Supplies Inc.',
    contactPerson: 'Sarah Johnson',
    email: 'sarah@chemsupplies.com',
    phone: '+1-555-0102',
    address: '456 Chemical Blvd',
    city: 'Chicago',
    country: 'USA',
    status: 'active',
    rating: 4.2,
    totalOrders: 32,
    lastOrderDate: new Date('2024-01-18'),
    categories: ['Chemicals', 'Reagents'],
    paymentTerms: 'Net 15',
    deliveryTime: '3-5 days',
    scalingPricing: {
      enabled: false,
      tiers: []
    }
  }
];

export function Suppliers() {
  const [suppliers, setSuppliers] = useState<Supplier[]>(initialSuppliers);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('basic');
  
  const [newSupplier, setNewSupplier] = useState({
    name: '',
    contactPerson: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    country: '',
    categories: '',
    paymentTerms: 'Net 30',
    deliveryTime: '5-7 days',
    scalingEnabled: false,
    scalingTiers: [
      { minQuantity: 1, maxQuantity: 10, discount: 0 },
      { minQuantity: 11, maxQuantity: 50, discount: 5 },
      { minQuantity: 51, maxQuantity: 999, discount: 10 }
    ]
  });

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleAddSupplier = useCallback(() => {
    if (!newSupplier.name || !newSupplier.contactPerson || !newSupplier.email) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (!validateEmail(newSupplier.email)) {
      toast.error('Please enter a valid email address');
      return;
    }

    const supplier: Supplier = {
      id: `${Date.now()}`,
      name: newSupplier.name,
      contactPerson: newSupplier.contactPerson,
      email: newSupplier.email,
      phone: newSupplier.phone,
      address: newSupplier.address,
      city: newSupplier.city,
      country: newSupplier.country,
      status: 'active',
      rating: 0,
      totalOrders: 0,
      lastOrderDate: new Date(),
      categories: newSupplier.categories.split(',').map(cat => cat.trim()).filter(cat => cat),
      paymentTerms: newSupplier.paymentTerms,
      deliveryTime: newSupplier.deliveryTime,
      scalingPricing: {
        enabled: newSupplier.scalingEnabled,
        tiers: newSupplier.scalingEnabled ? newSupplier.scalingTiers : []
      }
    };

    setSuppliers(prev => [...prev, supplier]);
    setNewSupplier({
      name: '',
      contactPerson: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      country: '',
      categories: '',
      paymentTerms: 'Net 30',
      deliveryTime: '5-7 days',
      scalingEnabled: false,
      scalingTiers: [
        { minQuantity: 1, maxQuantity: 10, discount: 0 },
        { minQuantity: 11, maxQuantity: 50, discount: 5 },
        { minQuantity: 51, maxQuantity: 999, discount: 10 }
      ]
    });
    setIsAddDialogOpen(false);
    setActiveTab('basic'); // Reset to basic tab
    toast.success('Supplier added successfully');
  }, [newSupplier]);

  const handleEditSupplier = useCallback((supplier: Supplier) => {
    setEditingSupplier(supplier);
    setIsEditDialogOpen(true);
  }, []);

  const handleDeleteSupplier = useCallback((supplierId: string) => {
    setSuppliers(prev => prev.filter(supplier => supplier.id !== supplierId));
    toast.success('Supplier deleted successfully');
  }, []);

  const handleStatusChange = useCallback((supplierId: string, newStatus: 'active' | 'inactive') => {
    setSuppliers(prev => prev.map(supplier => 
      supplier.id === supplierId ? { ...supplier, status: newStatus } : supplier
    ));
    toast.success('Supplier status updated');
  }, []);

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    }).format(date);
  };

  const handleScalingToggle = (checked: boolean, e?: React.MouseEvent) => {
    // Prevent event bubbling that might cause tab switching
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    setNewSupplier(prev => ({
      ...prev,
      scalingEnabled: checked
    }));
  };

  const updateScalingTier = (index: number, field: string, value: number) => {
    setNewSupplier(prev => ({
      ...prev,
      scalingTiers: prev.scalingTiers.map((tier, i) => 
        i === index ? { ...tier, [field]: value } : tier
      )
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Users className="h-6 w-6" />
          <h1 className="text-2xl font-bold">Suppliers</h1>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Supplier
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Supplier</DialogTitle>
              <DialogDescription>
                Add a new supplier with contact information and pricing details.
              </DialogDescription>
            </DialogHeader>
            
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="basic">Basic Info</TabsTrigger>
                <TabsTrigger value="contact">Contact Details</TabsTrigger>
                <TabsTrigger value="pricing">Scaling & Pricing</TabsTrigger>
              </TabsList>
              
              <TabsContent value="basic" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Company Name *</Label>
                    <Input
                      id="name"
                      value={newSupplier.name}
                      onChange={(e) => setNewSupplier(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter company name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="contactPerson">Contact Person *</Label>
                    <Input
                      id="contactPerson"
                      value={newSupplier.contactPerson}
                      onChange={(e) => setNewSupplier(prev => ({ ...prev, contactPerson: e.target.value }))}
                      placeholder="Enter contact person name"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="categories">Categories</Label>
                  <Input
                    id="categories"
                    value={newSupplier.categories}
                    onChange={(e) => setNewSupplier(prev => ({ ...prev, categories: e.target.value }))}
                    placeholder="Enter categories (comma separated)"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="paymentTerms">Payment Terms</Label>
                    <Select value={newSupplier.paymentTerms} onValueChange={(value) => setNewSupplier(prev => ({ ...prev, paymentTerms: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Net 15">Net 15</SelectItem>
                        <SelectItem value="Net 30">Net 30</SelectItem>
                        <SelectItem value="Net 60">Net 60</SelectItem>
                        <SelectItem value="COD">Cash on Delivery</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="deliveryTime">Delivery Time</Label>
                    <Input
                      id="deliveryTime"
                      value={newSupplier.deliveryTime}
                      onChange={(e) => setNewSupplier(prev => ({ ...prev, deliveryTime: e.target.value }))}
                      placeholder="e.g., 5-7 days"
                    />
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="contact" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={newSupplier.email}
                      onChange={(e) => setNewSupplier(prev => ({ ...prev, email: e.target.value }))}
                      placeholder="Enter email address"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      value={newSupplier.phone}
                      onChange={(e) => setNewSupplier(prev => ({ ...prev, phone: e.target.value }))}
                      placeholder="Enter phone number"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <Input
                    id="address"
                    value={newSupplier.address}
                    onChange={(e) => setNewSupplier(prev => ({ ...prev, address: e.target.value }))}
                    placeholder="Enter street address"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="city">City</Label>
                    <Input
                      id="city"
                      value={newSupplier.city}
                      onChange={(e) => setNewSupplier(prev => ({ ...prev, city: e.target.value }))}
                      placeholder="Enter city"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="country">Country</Label>
                    <Input
                      id="country"
                      value={newSupplier.country}
                      onChange={(e) => setNewSupplier(prev => ({ ...prev, country: e.target.value }))}
                      placeholder="Enter country"
                    />
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="pricing" className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="space-y-1">
                    <h4 className="font-medium">Enable Scaling Pricing</h4>
                    <p className="text-sm text-gray-500">
                      Offer volume discounts based on quantity tiers
                    </p>
                  </div>
                  <Switch
                    checked={newSupplier.scalingEnabled}
                    onCheckedChange={handleScalingToggle}
                    onClick={(e) => e.stopPropagation()}
                  />
                </div>
                
                {newSupplier.scalingEnabled && (
                  <div className="space-y-4">
                    <h4 className="font-medium">Pricing Tiers</h4>
                    {newSupplier.scalingTiers.map((tier, index) => (
                      <div key={index} className="grid grid-cols-4 gap-4 p-4 border rounded-lg">
                        <div className="space-y-2">
                          <Label>Min Quantity</Label>
                          <Input
                            type="number"
                            value={tier.minQuantity}
                            onChange={(e) => updateScalingTier(index, 'minQuantity', parseInt(e.target.value) || 0)}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Max Quantity</Label>
                          <Input
                            type="number"
                            value={tier.maxQuantity}
                            onChange={(e) => updateScalingTier(index, 'maxQuantity', parseInt(e.target.value) || 0)}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Discount (%)</Label>
                          <Input
                            type="number"
                            value={tier.discount}
                            onChange={(e) => updateScalingTier(index, 'discount', parseInt(e.target.value) || 0)}
                          />
                        </div>
                        <div className="flex items-end">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setNewSupplier(prev => ({
                                ...prev,
                                scalingTiers: prev.scalingTiers.filter((_, i) => i !== index)
                              }));
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                    <Button
                      variant="outline"
                      onClick={() => {
                        setNewSupplier(prev => ({
                          ...prev,
                          scalingTiers: [...prev.scalingTiers, { minQuantity: 0, maxQuantity: 0, discount: 0 }]
                        }));
                      }}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add Tier
                    </Button>
                  </div>
                )}
              </TabsContent>
            </Tabs>
            
            <div className="flex justify-end space-x-2 pt-4">
              <Button variant="outline" onClick={() => {
                setIsAddDialogOpen(false);
                setActiveTab('basic');
              }}>
                Cancel
              </Button>
              <Button onClick={handleAddSupplier}>
                Add Supplier
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Suppliers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{suppliers.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Suppliers</CardTitle>
            <Building className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {suppliers.filter(s => s.status === 'active').length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {suppliers.reduce((sum, s) => sum + s.totalOrders, 0)}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Rating</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {suppliers.length > 0 ? (suppliers.reduce((sum, s) => sum + s.rating, 0) / suppliers.length).toFixed(1) : '0.0'}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Suppliers List */}
      <Card>
        <CardHeader>
          <CardTitle>Suppliers List</CardTitle>
          <CardDescription>
            Manage your laboratory suppliers and their information.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {suppliers.map((supplier) => (
              <div key={supplier.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <h3 className="font-semibold text-lg">{supplier.name}</h3>
                    <Badge variant={supplier.status === 'active' ? 'default' : 'secondary'}>
                      {supplier.status.charAt(0).toUpperCase() + supplier.status.slice(1)}
                    </Badge>
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm">{supplier.rating.toFixed(1)}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Select
                      value={supplier.status}
                      onValueChange={(value: 'active' | 'inactive') => handleStatusChange(supplier.id, value)}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="inactive">Inactive</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEditSupplier(supplier)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDeleteSupplier(supplier.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <Mail className="h-4 w-4 text-gray-400" />
                    <div>
                      <span className="font-medium">Contact:</span>
                      <p className="text-gray-600">{supplier.contactPerson}</p>
                      <p className="text-gray-600">{supplier.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Phone className="h-4 w-4 text-gray-400" />
                    <div>
                      <span className="font-medium">Phone:</span>
                      <p className="text-gray-600">{supplier.phone}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-4 w-4 text-gray-400" />
                    <div>
                      <span className="font-medium">Location:</span>
                      <p className="text-gray-600">{supplier.city}, {supplier.country}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-gray-400" />
                    <div>
                      <span className="font-medium">Last Order:</span>
                      <p className="text-gray-600">{formatDate(supplier.lastOrderDate)}</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-3 flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-sm">
                    <span className="flex items-center">
                      <Package className="h-3 w-3 mr-1" />
                      {supplier.totalOrders} orders
                    </span>
                    <span className="flex items-center">
                      <DollarSign className="h-3 w-3 mr-1" />
                      {supplier.paymentTerms}
                    </span>
                    <span>Delivery: {supplier.deliveryTime}</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {supplier.categories.map((category, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {category}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                {supplier.scalingPricing.enabled && (
                  <div className="mt-3 p-2 bg-blue-50 rounded">
                    <span className="text-sm font-medium text-blue-800">Volume Pricing Available</span>
                    <div className="text-xs text-blue-600 mt-1">
                      {supplier.scalingPricing.tiers.length} pricing tiers configured
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}