import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { FileAttachmentComponent, FileAttachment } from '@/components/FileAttachment';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { 
  Microscope,
  Plus,
  Clock,
  CheckCircle,
  XCircle,
  Search,
  Filter,
  Building,
  Home
} from 'lucide-react';

interface Test {
  id: string;
  testNumber: string;
  name: string;
  description: string;
  category: 'personal-use' | 'industrial';
  testType: 'Chemical' | 'Microbiological' | 'Physical' | 'Environmental';
  status: 'pending' | 'in-progress' | 'completed' | 'failed' | 'cancelled';
  priority: 'low' | 'medium' | 'high';
  sampleId: string;
  sampleName: string;
  clientName?: string;
  clientType?: 'individual' | 'company';
  assignedTo: string;
  assignedBy: string;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
  dueDate: Date;
  completedAt?: Date;
  results?: string;
  notes: string;
  attachments: FileAttachment[];
  methodology: string;
  equipment: string;
  standards: string;
  cost: number;
  currency: string;
}

const initialTests: Test[] = [
  {
    id: 'test-001',
    testNumber: 'TEST-2024-001',
    name: 'Home Water Quality Analysis',
    description: 'Complete water quality testing for residential use',
    category: 'personal-use',
    testType: 'Chemical',
    status: 'completed',
    priority: 'medium',
    sampleId: 'HW-2024-001',
    sampleName: 'Home Water Sample',
    clientName: 'John Smith',
    clientType: 'individual',
    assignedTo: 'user-tech',
    assignedBy: 'user-lablead',
    createdBy: 'user-lablead',
    createdAt: new Date('2024-01-15T09:00:00Z'),
    updatedAt: new Date('2024-01-16T14:30:00Z'),
    dueDate: new Date('2024-01-20T17:00:00Z'),
    completedAt: new Date('2024-01-16T14:30:00Z'),
    results: 'pH: 7.2, Chlorine: 0.5 ppm, Heavy metals: Not detected. Water quality meets residential standards.',
    notes: 'Sample collected from kitchen tap. All parameters within acceptable range for drinking water.',
    methodology: 'EPA Method 150.1 - pH Electrometric, EPA Method 330.5 - Chlorine',
    equipment: 'pH Meter Model XYZ-123, Chlorine Test Kit',
    standards: 'EPA 150.1, EPA 330.5, WHO Guidelines',
    attachments: [],
    cost: 85.00,
    currency: 'USD'
  },
  {
    id: 'test-002',
    testNumber: 'TEST-2024-002',
    name: 'Industrial Wastewater Analysis',
    description: 'Comprehensive wastewater analysis for industrial discharge compliance',
    category: 'industrial',
    testType: 'Environmental',
    status: 'in-progress',
    priority: 'high',
    sampleId: 'IW-2024-001',
    sampleName: 'Factory Discharge Sample',
    clientName: 'ABC Manufacturing Corp.',
    clientType: 'company',
    assignedTo: 'user-analyst',
    assignedBy: 'user-lablead',
    createdBy: 'user-lablead',
    createdAt: new Date('2024-01-16T10:00:00Z'),
    updatedAt: new Date('2024-01-17T11:00:00Z'),
    dueDate: new Date('2024-01-22T17:00:00Z'),
    notes: 'Priority testing for regulatory compliance. Sample requires full panel analysis.',
    methodology: 'EPA Method 1664A - Oil and Grease, EPA Method 200.7 - Metals',
    equipment: 'GC-MS, ICP-MS, pH Meter',
    standards: 'EPA 1664A, EPA 200.7, Local Discharge Limits',
    attachments: [],
    cost: 450.00,
    currency: 'USD'
  }
];

const loadTests = (): Test[] => {
  try {
    const stored = localStorage.getItem('nbslims_tests_old');
    if (stored) {
      return JSON.parse(stored, (key, value) => {
        if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/.test(value)) {
          return new Date(value);
        }
        return value;
      });
    }
  } catch (error) {
    console.error('Error loading tests from localStorage:', error);
  }
  return initialTests;
};

const saveTests = (tests: Test[]) => {
  try {
    localStorage.setItem('nbslims_tests_old', JSON.stringify(tests));
  } catch (error) {
    console.error('Error saving tests to localStorage:', error);
  }
};

export function Tests() {
  const { user, hasPermission } = useAuth();
  const [tests, setTests] = useState<Test[]>(loadTests);
  const [selectedTest, setSelectedTest] = useState<string | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const [newTest, setNewTest] = useState({
    name: '',
    description: '',
    category: 'personal-use' as const,
    testType: 'Chemical' as const,
    priority: 'medium' as const,
    sampleId: '',
    sampleName: '',
    clientName: '',
    clientType: 'individual' as const,
    dueDate: '',
    notes: '',
    methodology: '',
    equipment: '',
    standards: '',
    cost: 0
  });

  React.useEffect(() => {
    saveTests(tests);
  }, [tests]);

  const canCreateTest = hasPermission('tests', 'create');
  const canUpdateTest = hasPermission('tests', 'update');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in-progress': return 'bg-blue-100 text-blue-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800';
      case 'cancelled': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4" />;
      case 'in-progress': return <Clock className="h-4 w-4" />;
      case 'pending': return <Clock className="h-4 w-4" />;
      case 'failed': return <XCircle className="h-4 w-4" />;
      case 'cancelled': return <XCircle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'personal-use': return 'bg-blue-100 text-blue-800';
      case 'industrial': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'personal-use': return <Home className="h-4 w-4" />;
      case 'industrial': return <Building className="h-4 w-4" />;
      default: return <Microscope className="h-4 w-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'Chemical': return 'bg-blue-100 text-blue-800';
      case 'Microbiological': return 'bg-green-100 text-green-800';
      case 'Physical': return 'bg-purple-100 text-purple-800';
      case 'Environmental': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredTests = tests.filter(test => {
    const matchesSearch = test.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         test.sampleName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         test.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         test.clientName?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || test.status === statusFilter;
    const matchesCategory = categoryFilter === 'all' || test.category === categoryFilter;
    
    return matchesSearch && matchesStatus && matchesCategory;
  });

  const handleAddTest = useCallback(() => {
    if (!newTest.name.trim() || !newTest.sampleId.trim()) {
      toast.error('Please fill in test name and sample ID');
      return;
    }

    const test: Test = {
      ...newTest,
      id: `test-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      testNumber: `TEST-${new Date().getFullYear()}-${String(tests.length + 1).padStart(3, '0')}`,
      status: 'pending',
      assignedTo: user?.id || '',
      assignedBy: user?.id || '',
      createdBy: user?.id || '',
      createdAt: new Date(),
      updatedAt: new Date(),
      dueDate: newTest.dueDate ? new Date(newTest.dueDate) : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      attachments: [],
      currency: 'USD'
    };

    setTests(prev => [test, ...prev]);
    setNewTest({
      name: '',
      description: '',
      category: 'personal-use',
      testType: 'Chemical',
      priority: 'medium',
      sampleId: '',
      sampleName: '',
      clientName: '',
      clientType: 'individual',
      dueDate: '',
      notes: '',
      methodology: '',
      equipment: '',
      standards: '',
      cost: 0
    });
    setIsAddDialogOpen(false);
    toast.success('Test created successfully');
  }, [newTest, user, tests.length]);

  const handleStatusChange = useCallback((testId: string, newStatus: string) => {
    setTests(prev => prev.map(test => 
      test.id === testId 
        ? { 
            ...test, 
            status: newStatus as any, 
            updatedAt: new Date(),
            completedAt: newStatus === 'completed' ? new Date() : undefined
          }
        : test
    ));
    toast.success('Test status updated');
  }, []);

  const handleFileUpload = useCallback(async (testId: string, files: File[]) => {
    const newAttachments: FileAttachment[] = await Promise.all(
      files.map(async (file) => {
        const base64 = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });

        return {
          id: `attachment-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          name: file.name,
          type: file.type,
          size: file.size,
          url: base64,
          uploadedBy: user?.fullName || 'Unknown',
          uploadedAt: new Date()
        };
      })
    );

    setTests(prev => prev.map(test => 
      test.id === testId 
        ? { ...test, attachments: [...test.attachments, ...newAttachments], updatedAt: new Date() }
        : test
    ));
  }, [user]);

  const handleFileDelete = useCallback((testId: string, attachmentId: string) => {
    setTests(prev => prev.map(test => 
      test.id === testId 
        ? { ...test, attachments: test.attachments.filter(att => att.id !== attachmentId), updatedAt: new Date() }
        : test
    ));
    toast.success('File deleted successfully');
  }, []);

  const selectedTestData = selectedTest ? tests.find(t => t.id === selectedTest) : null;

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    }).format(date);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  // Calculate statistics
  const totalTests = tests.length;
  const personalTests = tests.filter(t => t.category === 'personal-use').length;
  const industrialTests = tests.filter(t => t.category === 'industrial').length;
  const completedTests = tests.filter(t => t.status === 'completed').length;
  const pendingTests = tests.filter(t => t.status === 'pending').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Laboratory Tests</h1>
          <p className="text-gray-600">Manage tests for personal use and industrial clients</p>
        </div>
        {canCreateTest && (
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                New Test
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Test</DialogTitle>
                <DialogDescription>
                  Create a new test for personal use or industrial client
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Test Name *</Label>
                    <Input
                      id="name"
                      value={newTest.name}
                      onChange={(e) => setNewTest(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter test name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="category">Category *</Label>
                    <Select value={newTest.category} onValueChange={(value: any) => setNewTest(prev => ({ ...prev, category: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="personal-use">Personal Use</SelectItem>
                        <SelectItem value="industrial">Industrial</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="sampleId">Sample ID *</Label>
                    <Input
                      id="sampleId"
                      value={newTest.sampleId}
                      onChange={(e) => setNewTest(prev => ({ ...prev, sampleId: e.target.value }))}
                      placeholder="Enter sample ID"
                    />
                  </div>
                  <div>
                    <Label htmlFor="clientName">Client Name</Label>
                    <Input
                      id="clientName"
                      value={newTest.clientName}
                      onChange={(e) => setNewTest(prev => ({ ...prev, clientName: e.target.value }))}
                      placeholder="Enter client name"
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddTest}>
                    Create Test
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Microscope className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-sm text-gray-600">Total Tests</p>
                <p className="text-2xl font-bold">{totalTests}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Home className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-sm text-gray-600">Personal Use</p>
                <p className="text-2xl font-bold">{personalTests}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Building className="h-5 w-5 text-purple-500" />
              <div>
                <p className="text-sm text-gray-600">Industrial</p>
                <p className="text-2xl font-bold">{industrialTests}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-sm text-gray-600">Completed</p>
                <p className="text-2xl font-bold">{completedTests}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-yellow-500" />
              <div>
                <p className="text-sm text-gray-600">Pending</p>
                <p className="text-2xl font-bold">{pendingTests}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search tests by name, sample, client, or description..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="personal-use">Personal Use</SelectItem>
                <SelectItem value="industrial">Industrial</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Tests Table */}
      <Card>
        <CardHeader>
          <CardTitle>Tests ({filteredTests.length})</CardTitle>
          <CardDescription>
            Laboratory tests for personal use and industrial clients
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Test #</TableHead>
                <TableHead>Test Name</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Client</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Cost</TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTests.map((test) => (
                <TableRow key={test.id} className="cursor-pointer hover:bg-gray-50" onClick={() => setSelectedTest(test.id)}>
                  <TableCell className="font-medium">{test.testNumber}</TableCell>
                  <TableCell>
                    <div>
                      <p className="font-medium">{test.name}</p>
                      <p className="text-sm text-gray-500">Sample: {test.sampleId}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      {getCategoryIcon(test.category)}
                      <Badge className={getCategoryColor(test.category)}>
                        {test.category === 'personal-use' ? 'Personal Use' : 'Industrial'}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getTypeColor(test.testType)}>
                      {test.testType}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div>
                      <p className="font-medium">{test.clientName || 'N/A'}</p>
                      <p className="text-sm text-gray-500">{test.clientType}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(test.status)}
                      <Badge className={getStatusColor(test.status)}>
                        {test.status.charAt(0).toUpperCase() + test.status.slice(1).replace('-', ' ')}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell>{formatCurrency(test.cost)}</TableCell>
                  <TableCell>{formatDate(test.dueDate)}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      {canUpdateTest && (
                        <Select
                          value={test.status}
                          onValueChange={(value) => handleStatusChange(test.id, value)}
                          onClick={(e) => e.stopPropagation()}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">Pending</SelectItem>
                            <SelectItem value="in-progress">In Progress</SelectItem>
                            <SelectItem value="completed">Completed</SelectItem>
                            <SelectItem value="failed">Failed</SelectItem>
                            <SelectItem value="cancelled">Cancelled</SelectItem>
                          </SelectContent>
                        </Select>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Test Detail Dialog */}
      <Dialog open={!!selectedTest} onOpenChange={() => setSelectedTest(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          {selectedTestData && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center justify-between">
                  <span>{selectedTestData.name}</span>
                  <div className="flex items-center space-x-2">
                    <Badge className={getCategoryColor(selectedTestData.category)}>
                      {selectedTestData.category === 'personal-use' ? 'Personal Use' : 'Industrial'}
                    </Badge>
                    <Badge className={getTypeColor(selectedTestData.testType)}>
                      {selectedTestData.testType}
                    </Badge>
                  </div>
                </DialogTitle>
                <DialogDescription>
                  {selectedTestData.testNumber} • Created on {formatDate(selectedTestData.createdAt)} • Sample: {selectedTestData.sampleId}
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-6">
                <div>
                  <h4 className="font-medium mb-2">Description</h4>
                  <p className="text-gray-600">{selectedTestData.description}</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium mb-2">Client Information</h4>
                    <p className="text-gray-600">{selectedTestData.clientName || 'N/A'}</p>
                    <p className="text-sm text-gray-500">{selectedTestData.clientType}</p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Cost</h4>
                    <p className="text-gray-600">{formatCurrency(selectedTestData.cost)}</p>
                  </div>
                </div>

                {selectedTestData.results && (
                  <div>
                    <h4 className="font-medium mb-2">Results</h4>
                    <p className="text-gray-600">{selectedTestData.results}</p>
                  </div>
                )}

                {selectedTestData.notes && (
                  <div>
                    <h4 className="font-medium mb-2">Notes</h4>
                    <p className="text-gray-600">{selectedTestData.notes}</p>
                  </div>
                )}

                <Separator />

                <div>
                  <h4 className="font-medium mb-4">Test Files & Documentation</h4>
                  <FileAttachmentComponent
                    attachments={selectedTestData.attachments}
                    onUpload={(files) => handleFileUpload(selectedTestData.id, files)}
                    onDelete={(attachmentId) => handleFileDelete(selectedTestData.id, attachmentId)}
                    maxFileSize={20}
                    allowedTypes={[
                      'image/jpeg',
                      'image/png',
                      'image/gif',
                      'image/webp',
                      'application/pdf',
                      'application/msword',
                      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                      'application/vnd.ms-excel',
                      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                      'text/plain',
                      'text/csv'
                    ]}
                    maxFiles={15}
                  />
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}